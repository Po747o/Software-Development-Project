﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Primeiro_Projeto_PDS.Formularios;

namespace Primeiro_Projeto_PDS.RegrasDeNegocio
{
    internal class Contato
    {
        
    }
}
