﻿namespace Primeiro_Projeto_PDS.Formularios
{
    partial class ApresentacaoInformacoes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.edApresentacao = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // edApresentacao
            // 
            this.edApresentacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edApresentacao.Location = new System.Drawing.Point(94, 68);
            this.edApresentacao.Multiline = true;
            this.edApresentacao.Name = "edApresentacao";
            this.edApresentacao.Size = new System.Drawing.Size(599, 325);
            this.edApresentacao.TabIndex = 0;
            // 
            // ApresentacaoInformacoes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.edApresentacao);
            this.Name = "ApresentacaoInformacoes";
            this.Text = "ApresentacaoInformacoes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox edApresentacao;
    }
}