﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Primeiro_Projeto_PDS.Formularios;

namespace Primeiro_Projeto_PDS.Formularios
{
    public partial class CadastroDeContato : Form
    {
        public CadastroDeContato()
        {
            InitializeComponent();
            btCancelar.Enabled = false;
            btSalvar.Enabled = false;
            edNome.Enabled = false;
            edSexo.Enabled = false;
            edNascimento.Enabled = false;
            edEmail.Enabled = false;
            edTelefone.Enabled = false;
        }

        private void btAdicionar_Click(object sender, EventArgs e)
        {
            btCancelar.Enabled = true;
            btSalvar.Enabled =true;
            edNome.Enabled = true;
            edSexo.Enabled = true;
            edNascimento.Enabled = true;
            edEmail.Enabled = true;
            edTelefone.Enabled = true;
            btAdicionar.Enabled = false;
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            //limpar campos
            edNome.Clear();
            edSexo.Clear();
            edNascimento.Clear();
            edEmail.Clear();
            edTelefone.Clear();
            btAdicionar.Enabled = true;
            btCancelar.Enabled = false;
            btSalvar.Enabled = false;
            edNome.Enabled = false;
            edSexo.Enabled = false;
            edNascimento.Enabled = false;
            edEmail.Enabled = false;
            edTelefone.Enabled = false;
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            edNome.Clear();
            edSexo.Clear();
            edNascimento.Clear();
            edEmail.Clear();
            edTelefone.Clear();
            btAdicionar.Enabled = true;
            btCancelar.Enabled = false;
            btSalvar.Enabled = false;
            edNome.Enabled = false;
            edSexo.Enabled = false;
            edNascimento.Enabled = false;
            edEmail.Enabled = false;
            edTelefone.Enabled = false;

            Form ApresentacaoInformacoes = new Form();
            InitializeComponent();
            
        }
    }
}
