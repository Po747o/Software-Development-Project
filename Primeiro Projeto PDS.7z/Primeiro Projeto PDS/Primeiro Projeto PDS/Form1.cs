﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Primeiro_Projeto_PDS.Formularios;//eu deveria não ter usado espaço no nome do projeto

namespace Primeiro_Projeto_PDS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCadastrarContato_Click(object sender, EventArgs e)
        {
            new CadastroDeContato().ShowDialog();
        }
    }
}
